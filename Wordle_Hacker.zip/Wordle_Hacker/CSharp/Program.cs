﻿using System;
using System.IO;
using System.Linq;
using CSharpTools;
using System.Collections.Generic;

namespace WordleHacker
{
	public static partial class Hacker
	{
		public const string wordleDictionaryPath = @"Dictionaries/Wordle_english.txt";
		public const string commonEnglishPath = @"Dictionaries/Common USA english.txt";
		public const string wordleWordsPath = @"Dictionaries/Wordle words.txt";
		public const string outputPath = @"Output.txt";
		public static Dictionary<char, float> letterValues = new Dictionary<char, float>();
		
		public static int currentTurn = 0;
		private static WordleDictionary? wordleDictionary;
		
		public static void Main()
		{
			SetupLetterValues();
			/*wordleDictionary = GenerateDictionary();
			else*/ wordleDictionary = WordleDictionary.ReadWordleDictionary(wordleDictionaryPath);
			Run();
		}
		
		private static bool Run()
		{
			File.WriteAllText(outputPath, "Enter your first word in the app!");
			
			Console2.WriteAnimateLetters("Welcome, ", 120, false);
			Console2.Sleep(200);
			Console2.WriteAnimateWords("to the Wordle Hacker.", 260, false);
			for(int i = 0; i < 2; i++) Console2.WriteLine(false);
			Console2.Sleep(500);
			Console2.Clear();
			
			WordleWord wordleWord;
			for(int i = 0; i < 6; i++)
			{
				if(GetNextWordleWord(i, out wordleWord)) {
					Console2.Clear();
					Console2.WriteLine("Filtering dictionary...");
					wordleDictionary?.FilterDictionary(wordleWord);
					Console2.Clear();
					
					Console2.Write("Found "+ wordleDictionary?.words.Count +" words using ");
					WriteWordleWord(wordleWord);
					Console2.WriteLine(" as a filter.");
					Console2.WriteLine();
					
					wordleDictionary?.Sort();
					
					if(wordleDictionary?.words.Count == 2) Console2.WriteLine("Found todays wordle! "+ wordleDictionary?.words[0]);
					else{
						Console.Write("Recommended next words: ");
						int idx = 0;
						foreach(string word in wordleDictionary.words) {
							if(idx != 2) Console.Write(word +", ");
							else{
								Console.Write(word);
								break;
							}
							
							idx++;
						}
					}
					wordleDictionary?.TotxtFile(outputPath);
					Console2.WriteLine();
					
					Console2.Write("Press [enter] to continue ");
					Console2.ReadLine();
					Console2.Clear();
				}else return false;
				
				currentTurn++;
			}
			return true;
		}

		private static bool GetNextWordleWord(int numOfWords, out WordleWord wordleWord)
		{
			wordleWord = new WordleWord();
			string numWordsDone = "not assigned";
			
			switch(numOfWords)
			{
				case 0:
					numWordsDone = "first";
					break;
				case 1:
					numWordsDone = "second";
					break;
				case 2:
					numWordsDone = "third";
					break;
				case 3:
					numWordsDone = "fouth";
					break;
				case 4:
					numWordsDone = "fifth";
					break;
				case 5:
					numWordsDone = "sixth";
					break;
			}
			string word = "unassigned";
			int i = 0;
			while(true)
			{
				if(numWordsDone == "first") Console2.WriteLine("Recommended starting word: soare");
				string sentance = "Enter your "+ numWordsDone +" word: ";
				if(i == 0) {
					Console2.WriteAnimateWords(sentance, 200, false);
					Console2.textSave.textLines.Add(new TextLineSave(sentance, TextPrintMode.Write));
				}else Console2.WriteLine(sentance);
				
				word = Console2.ReadLine();
				if(word.Length == 5) {
					break;
				}else{
					Console2.WriteIncorrect("Word length must be 5 letters.");
					Console2.Sleep(1200);
					Console2.Clear();
				}
				
				i++;
			}
			
			Console2.Write("Now enter a colour for each of the letters in the word '"+ word +"'.");
			DisplayWordleColors();
			
			i = 0;
			foreach (char letter in word)
			{
				Console2.Write((i + 1) + ". " + letter + ": ");
				string state = Console2.ReadLine(false);

				TextSave save = TextSave.DuplicateSave(Console2.textSave);
				Console2.Clear();
				save.PrintText();
				
				switch (state)
				{
					case "green":
					case "g":
						wordleWord.AddLetter(new WordleLetter(letter, LetterState.CorrectLocation));
						Console2.WriteLineInColor(state, ConsoleColor.Black, ConsoleColor.Green);
						break;
					
					case "yellow":
					case "y":
						wordleWord.AddLetter(new WordleLetter(letter, LetterState.WrongLocation));
						Console2.WriteLineInColor(state, ConsoleColor.Black, ConsoleColor.Yellow);
						break;
						
					case "grey":
					case "gray":
					case "gr":
						wordleWord.AddLetter(new WordleLetter(letter, LetterState.DoesNotContain));
						Console2.WriteLineInColor(state, ConsoleColor.Black, ConsoleColor.Gray);
						break;

					default:
						Console2.WriteIncorrect("State must be one of the colours listed above.");
						return false;
				}
				i++;
			}
			
			Console2.Sleep(800);
			return true;
		}
	}
}