﻿using System;
using CSharpTools;

namespace WordleHacker
{
    public static partial class Hacker
    {
    	private static WordleDictionary GenerateDictionary()
		{
			Console2.WriteLine("Rebiulding dictionary...");
			WordDictionary usaDictionary = new WordDictionary(@"Dictionaries/USA_english.txt");
			WordDictionary ukDictionary = new WordDictionary(@"Dictionaries/UK_english.txt");
			
			WordleDictionary wordleDictionary = new WordleDictionary(wordleDictionaryPath, false, usaDictionary, ukDictionary);
			Console.Clear();
			return wordleDictionary;
		}
		
		private static void WriteWordleWord(WordleWord word)
		{
			foreach(WordleLetter letter in word.letters) {
				switch(letter.state) {
					
					case LetterState.CorrectLocation:
						Console2.WriteInColor(Convert.ToString(letter.letter), ConsoleColor.Black, ConsoleColor.Green);
						break;
					
					case LetterState.WrongLocation:
						Console2.WriteInColor(Convert.ToString(letter.letter), ConsoleColor.Black, ConsoleColor.Yellow);
						break;
						
					case LetterState.DoesNotContain:
						Console2.WriteInColor(Convert.ToString(letter.letter), ConsoleColor.Black, ConsoleColor.Gray);
						break;
				}
			}
		}
		
		private static void DisplayWordleColors()
		{
			Console2.WriteLine();
			Console2.WriteInColor("g = green, ", ConsoleColor.Black, ConsoleColor.Green);
			Console2.WriteInColor("y = yellow, ", ConsoleColor.Black, ConsoleColor.Yellow);
			Console2.WriteLineInColor("gr = grey,", ConsoleColor.Black, ConsoleColor.Gray);
			Console2.WriteLine();
		}
		
		public static int FindWordValue(ref WordDictionary dictionary, string inputWord)
		{
			int value = 0;
			for(int i = dictionary.words.Length - 1; i > -1; i--)
			{
				string word = dictionary.words[i];
				if(word == inputWord) return value;
				value++;
			}
			return -1;
		}
		
		private static void SetupLetterValues()
		{
			letterValues.Add('a', 8.2f);
			letterValues.Add('b', 1.5f);
			letterValues.Add('c', 2.8f);
			letterValues.Add('d', 4.3f);
			letterValues.Add('e', 13);
			letterValues.Add('f', 2.2f);
			letterValues.Add('g', 2f);
			letterValues.Add('h', 6.1f);
			letterValues.Add('i', 7f);
			letterValues.Add('j', 0.15f);
			letterValues.Add('k', 0.77f);
			letterValues.Add('l', 4f);
			letterValues.Add('m', 6.7f);
			letterValues.Add('n', 6.7f);
			letterValues.Add('o', 7.5f);
			letterValues.Add('p', 1.9f);
			letterValues.Add('q', 0.095f);
			letterValues.Add('r', 6f);
			letterValues.Add('s', 6.3f);
			letterValues.Add('t', 9.1f);
			letterValues.Add('u', 2.8f);
			letterValues.Add('v', 0.98f);
			letterValues.Add('w', 2.4f);
			letterValues.Add('x', 0.15f);
			letterValues.Add('y', 2f);
			letterValues.Add('z', 0.0074f);
		}
	}
}