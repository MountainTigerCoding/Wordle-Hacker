﻿using System;
using System.IO;
using System.Collections.Generic;

namespace CSharpTools
{
    public class TextSave 
    {         
    	public List<TextLineSave> textLines {get; set;} = new List<TextLineSave>();
    	
    	public void PrintText(bool saveText = true){
    		TextLineSave[] tempTextLineSave = textLines.ToArray();
    		
    		foreach(TextLineSave element in tempTextLineSave) {
    			element.PrintText(saveText);
    		}
    	}
    	
    	public void OverwriteFromSave(TextSave textSave) {
    		textLines.Clear();
    		
    		foreach(TextLineSave element in textSave.textLines) {
    			textLines.Add(element);
    		}
    	}
    	
    	public void CopyFromSave(TextSave textSave) {
    		foreach(TextLineSave element in textSave.textLines) {
    	 		textLines.Add(element);
    		}
    	}
    	
    	public static TextSave DuplicateSave(TextSave textSave) {
    		TextSave cacheTextSave = new TextSave();
    		foreach(TextLineSave element in textSave.textLines) cacheTextSave.textLines.Add(element);
    		return cacheTextSave;
    	}

		public void Save(string text, TextPrintMode printMode, ConsoleColor foregroundColor = ConsoleColor.White, ConsoleColor backgroundColor = ConsoleColor.Black) {
			textLines.Add(new TextLineSave(text, printMode, backgroundColor, foregroundColor));
		}
    
    	public void OverwriteFromConsoleSave() => OverwriteFromSave(Console2.textSave);
    }
}