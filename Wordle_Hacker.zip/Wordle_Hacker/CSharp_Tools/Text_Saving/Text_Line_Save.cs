﻿using System;

namespace CSharpTools
{
    public struct TextLineSave 
    {   
    	public string text {get; set;}
        public TextPrintMode textPrintMode {get; set;}
        public ConsoleColor foregroundColor {get; set;}
        public ConsoleColor backgroundColor {get; set;}
        
        //constructor
        public TextLineSave(string text,  TextPrintMode textPrintMode = TextPrintMode.WriteLine, ConsoleColor backgoundColor = ConsoleColor.Black, ConsoleColor foregroundColor = ConsoleColor.White) {
        	this.text = text;
        	this.textPrintMode = textPrintMode;
        	this.backgroundColor = backgoundColor;
        	this.foregroundColor = foregroundColor;
        }
        
        public void PrintText(bool saveText = true) {
        	string displayedText = text;
        	
        	//write the text to the screen
        	if(textPrintMode == TextPrintMode.WriteLine) {
        		if(text != null) {
        			Console2.WriteLineInColor(displayedText, backgroundColor, foregroundColor, saveText);
        		}else{
        			Console2.WriteLine();
        		}
        	}else{
           		Console2.WriteInColor(displayedText, backgroundColor,foregroundColor, saveText);
        	}
        }
    }
}