﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using CSharpTools.Formatters;

namespace CSharpTools
{
    public class StringLog
    {
    	private string _path;
    	public string path {get => _path;}
		
    	//constructor
    	public StringLog(string path) {
    		_path = path;
    	}
    		
    	//save to the log when called
    	public void Log(string value) {
    		string[] _log;
    		
            if(File.Exists(_path)) {
    			//if the file does exist then read it
            	_log = CSVFormatter.ReadAllCSV(_path);
            }else{
            	//create a temp array as though it was the original csv
            	_log = new string[0];
            	RestoreFile.Restore(path); 
    	    }
    	    
    	    //convert to a list and add the new item
    	    List<string> listLog = _log.ToList();
    	    listLog.Add(value);
    	    
    	    //convert back to an array
    	    string[] tempLog = listLog.ToArray();
    	    
    	    CSVFormatter.WriteCSV(path, tempLog);
    	}
    	
    	//load the log when called
    	public string[] LoadLog() {
    		return CSVFormatter.ReadAllCSV(_path);
    	}
    	
    	//clear the log when called
    	public void Clear() => File.WriteAllText(path, null);
    }
}