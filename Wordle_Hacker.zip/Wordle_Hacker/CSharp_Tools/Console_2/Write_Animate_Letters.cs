﻿using System;

namespace CSharpTools
{
    public static partial class Console2
    {         
        public static void WriteAnimateLetters(string input, int delay = 0, bool saveText = true) {
            
			foreach(char element in input) {
				Console2.Write(element, saveText);
				if(element != ' ') Console2.Sleep(delay);
			}
        }
    }
}