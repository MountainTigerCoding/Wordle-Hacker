﻿using System;
using System.Threading;
using System.Collections.Generic;

namespace CSharpTools
{
    public static partial class Console2
    {
    	//writeLine method overflows
    	public static void WriteLine(bool saveText = true) => WriteLineAndSave(null!, saveText);
    	public static void WriteNewLineDelay(int delay, bool saveText) {
    		WriteLineAndSave(null!, saveText);
    		Thread.Sleep(delay);
    	}
    	
        public static void WriteLine(string input, bool saveText = true) => WriteLineAndSave(input, saveText);
        public static void WriteLine(string input, int delay, bool saveText = true) {
        	WriteLineAndSave(input, saveText);
        	Thread.Sleep(delay);
        }
       
        public static void WriteLine(char input, bool saveText = true) => WriteLineAndSave(Convert.ToString(input), saveText);
       
        //takes in standard arrays
        public static void WriteLine<T> (T[] input, bool saveText = true) {
        	if(input == null) {
        		WriteAndSave("writeLine list method.input = null", false);
        		Thread.Sleep(500);
        		return;
        	}
        	foreach(T element in input) {
        		WriteLineAndSave(Convert.ToString(element) ?? "WriteLine<T>.input in a foreach loop is mull", saveText);
        	}
        }
        
        //takes in standard arrays with delay
        public static void WriteLine<T> (T[] input, int delay, bool saveText = true) {
        	if(input == null) {
        		WriteAndSave("writeLine<T> method.input = null", false);
        		Thread.Sleep(delay);
        		return;
        	}
        	foreach(T element in input) {
        		WriteLineAndSave(Convert.ToString(element) ?? "WriteLine<T>.input in a foreach loop is mull", saveText);
        		Thread.Sleep(delay);
        	}
        }
        
        public static void WriteLine(int input, bool saveText = true) => WriteLineAndSave(Convert.ToString(input), saveText);
        public static void WriteLine(int input, int delay, bool saveText = true) {
        	WriteLineAndSave(Convert.ToString(input), saveText);
        	Thread.Sleep(delay);
        }
        
        public static void WriteLine(float input, bool saveText = true) => WriteLineAndSave(Convert.ToString(input), saveText);
        public static void WriteLine(float input, int delay, bool saveText = true) {
        	WriteLineAndSave(Convert.ToString(input), saveText);
        	Thread.Sleep(delay);
        }
        
        public static void WriteLine(double input, bool saveText = true) => WriteLineAndSave(Convert.ToString(input), saveText);
        public static void WriteLine(double input, int delay, bool saveText = true) {
        	WriteLineAndSave(Convert.ToString(input), saveText);
        	Thread.Sleep(delay);
        }
        
        public static void WriteLine(bool input, bool saveText = true) => WriteLineAndSave(Convert.ToString(input), saveText);
        public static void WriteLine(bool input, int delay, bool saveText = true) {
        	WriteLineAndSave(Convert.ToString(input), saveText);
        	Thread.Sleep(delay);
        }
        
        public static void WriteLine(uint input, bool saveText = true) => WriteLineAndSave(Convert.ToString(input), saveText);
    	public static void WriteLine(uint input, int delay, bool saveText = true) {
    		WriteLineAndSave(Convert.ToString(input), saveText);
    		Thread.Sleep(delay);
    	}
    	
    	public static void WriteLine<T>(T input, bool saveText = true) => WriteLineAndSave(Convert.ToString(input) ?? throw new NullReferenceException(), saveText);
    	public static void WriteLine<T>(T input, int delay, bool saveText = true) {
    		WriteLineAndSave(Convert.ToString(input) ?? throw new NullReferenceException(), saveText);
    		Thread.Sleep(delay);
    	}
    }
}