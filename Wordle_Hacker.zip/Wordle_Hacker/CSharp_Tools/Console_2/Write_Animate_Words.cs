﻿namespace CSharpTools
{
    public static partial class Console2
    {         
        public static void WriteAnimateWords(string words, int delay = 0, bool saveText = true) {
        	
        	foreach(char element in words) {
        		Console2.Write(element, saveText);
        	    if(element == System.Convert.ToChar(" ")) Console2.Sleep(delay);
        	}
        	
        	Console2.Sleep(400);
        }
    }
}