﻿namespace CSharpTools
{
    public static partial class Console2
    {
    	private static TextSave _textSave = new TextSave();
    	public static TextSave textSave {get => _textSave;}

        private static TextSave _absoluteTextSave = new TextSave();
    	public static TextSave absoluteTextSave {get => _textSave;}
    	
        private static void WriteLineAndSave(string input, bool saveText) {
        	if(input != null) Console.WriteLine(input);
        	else Console.WriteLine();
        	
            _absoluteTextSave.textLines.Add(new TextLineSave(input!, TextPrintMode.WriteLine, Console.BackgroundColor, Console.ForegroundColor) );
        	if(saveText) _textSave.textLines.Add(new TextLineSave(input!, TextPrintMode.WriteLine, Console.BackgroundColor, Console.ForegroundColor) );
        }
        
        
        private static void WriteAndSave(string input, bool saveText) {
            Console.Write(input);
            _absoluteTextSave.textLines.Add(new TextLineSave(input, TextPrintMode.Write, Console.BackgroundColor, Console.ForegroundColor) );
        	if(saveText) _textSave.textLines.Add(new TextLineSave(input, TextPrintMode.Write, Console.BackgroundColor, Console.ForegroundColor) );
        }
        
        public static void Clear() {
        	Console.Clear();
        	_textSave.textLines.Clear();
            _absoluteTextSave.textLines.Clear();
        }

        public static string ReadLine(bool saveText = true) {
            string? input = Console.ReadLine();
            if(saveText) _textSave.Save(input!, TextPrintMode.WriteLine, Console.ForegroundColor, Console.BackgroundColor);
            _absoluteTextSave.Save(input!, TextPrintMode.WriteLine, Console.ForegroundColor, Console.BackgroundColor);
            return input!;
        }

        public static void Sleep(int milliseconds) {
            System.Threading.Thread.Sleep(milliseconds);
        }
    }
    
    public enum TextPrintMode {Write, WriteLine}
}