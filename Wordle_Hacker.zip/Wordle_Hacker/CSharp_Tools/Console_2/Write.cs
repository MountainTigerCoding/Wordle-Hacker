﻿using System;
using System.Threading;

namespace CSharpTools
{
    public static  partial class Console2
    {         
        //write method overflows
        public static void Write(string input, bool saveText = true) => WriteAndSave(input, saveText);
        public static void Write(string input, int delay, bool saveText = true) {
        	WriteAndSave(input, saveText);
        	Thread.Sleep(delay);
        }
        
        public static void Write(char input, bool saveText = true) => WriteAndSave(Convert.ToString(input), saveText);
        public static void Write(char input, int delay, bool saveText = true) {
        	WriteAndSave(Convert.ToString(input), saveText);
        	Thread.Sleep(delay);
        }
        
        public static void Write(int input, bool saveText = true) => WriteAndSave(Convert.ToString(input), saveText);
        public static void Write(int input, int delay, bool saveText = true) {
        	WriteAndSave(Convert.ToString(input), saveText);
        	Thread.Sleep(delay);
        }
        
        public static void Write(float input, bool saveText = true) => WriteAndSave(Convert.ToString(input), saveText);
        public static void Write(float input, int delay, bool saveText = true) {
        	WriteAndSave(Convert.ToString(input), saveText);
        	Thread.Sleep(delay);
        }
            
        public static void Write(double input, bool saveText = true) => WriteAndSave(Convert.ToString(input), saveText);
        public static void Write(double input, int delay, bool saveText = true){
        	WriteAndSave(Convert.ToString(input), saveText);
        	Thread.Sleep(delay);
        }
        
        public static void Write(uint input, bool saveText = true) => WriteAndSave(Convert.ToString(input), saveText);
    	public static void Write(uint input, int delay, bool saveText = true) {
    		WriteAndSave(Convert.ToString(input), saveText);
    		Thread.Sleep(delay);
    	}
    }
}