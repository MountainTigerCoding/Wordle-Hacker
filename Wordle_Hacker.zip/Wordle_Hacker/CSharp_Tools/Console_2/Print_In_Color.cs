﻿using System;

namespace CSharpTools
{
    public static partial class Console2
    {   
    	public static void WriteLineCorrect(string input, bool saveText = true) {
    		SetCorrectConsoleColors();
    		Console2.WriteLine(input, saveText);
    		Console.ResetColor();
    	}
    	
    	public static void WriteLineCorrect(string input, int delay, bool saveText = true) {
    		SetCorrectConsoleColors();
    		Console2.WriteLine(input, delay, saveText);
    		Console.ResetColor();
    	}
    	
    	public static void WriteLineIncorrect(string input, bool saveText = true) {
    		SetIncorrectConsoleColors();
    		Console2.WriteLine(input, saveText);
    		Console.ResetColor();
    	}
    	
    	
    	public static void WriteCorrect(string input, bool saveText = true) {
    		SetCorrectConsoleColors();
    		Console2.Write(input, saveText);
    		Console.ResetColor();
    	}
    	
    	public static void WriteCorrect(string input, int delay, bool saveText = true) {
    		SetCorrectConsoleColors();
    		Console2.Write(input, delay, saveText);
    		Console.ResetColor();
    	}
    	
    	public static void WriteIncorrect(string input, bool saveText = true) {
    		SetIncorrectConsoleColors();
    		Console2.Write(input, saveText);
    		Console.ResetColor();
    	}
  
		private static void SetCorrectConsoleColors() {
        	Console.ResetColor();
        	Console.ForegroundColor = ConsoleColor.Green;
        }
        
        private static void SetIncorrectConsoleColors() {
        	Console.ResetColor();
        	Console.ForegroundColor = ConsoleColor.Red;
        }
        
        
        /*
        Custom color prints
        */
        
         private static void SetConsoleColors(ConsoleColor backgroundColor, ConsoleColor foregroundColor) {
        	Console.ResetColor();
        	
        	if(backgroundColor != ConsoleColor.Black) Console.BackgroundColor = backgroundColor;
        	Console.ForegroundColor = foregroundColor;
        }
        
        
        public static void WriteLineInColor(string input, ConsoleColor foregroundColor, ConsoleColor backgroundColor, bool saveText = true) {
        	SetConsoleColors(foregroundColor, backgroundColor);
        	Console2.WriteLine(input, saveText);
        	Console.ResetColor();
        }

		public static void WriteLineInColor(string input, int delay, ConsoleColor foregroundColor, ConsoleColor backgroundColor, bool saveText = true) {
        	SetConsoleColors(foregroundColor, backgroundColor);
        	Console2.WriteLine(input, delay, saveText);
        	Console.ResetColor();
        }
        
        public static void WriteInColor(string input, ConsoleColor foregroundColor, ConsoleColor backgroundColor, bool saveText = true) {
        	SetConsoleColors(foregroundColor, backgroundColor);
        	Console2.Write(input, saveText);
        	Console.ResetColor();
        }
	
		public static void WriteInColor(string input, int delay, ConsoleColor foregroundColor, ConsoleColor backgroundColor, bool saveText = true) {
        	SetConsoleColors(foregroundColor, backgroundColor);
        	Console2.Write(input, delay, saveText);
        	Console.ResetColor();
        }
    }
}