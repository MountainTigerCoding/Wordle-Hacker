﻿using System;
using System.Threading;

namespace CSharpTools
{
    public static partial class LoadingScreen
    {   
    	//load percentage overflows
    	public static void LoadPercentage(string loadingName) => _LoadPercentage("", loadingName, 10, 60);
        
        public static void LoadPercentage(string loadingType, string loadingName, int speed) => _LoadPercentage(loadingType, loadingName, speed, 15);
        
        public static void LoadPercentage(string loadingType, string loadingName, int speed, int waitingPercentage) => _LoadPercentage(loadingType, loadingName, speed, waitingPercentage);
        
        //private load percentage from overflows
        private static void _LoadPercentage(string loadingType, string loadingName, int speed, int waitingPercentage) {
        	int percentage = 0;
        	int increment = 1;
        	Random rnd = new Random();
        	
        	//clamp the waiting percentage 0 - 100
            waitingPercentage = Math.Clamp(waitingPercentage, 0, 100);
        	
        	//display whats happening and then load
        	Console2.Write(loadingType +": "+ loadingName);
        	for(int i = 0; i < 3; i++) {
        		Thread.Sleep(400);
        		Console2.Write(".");
        	}
        	
        	Thread.Sleep(500);
        	
        	//repeat untill 100 percent
        	while(percentage != 100) {
        		
        		increment = rnd.Next(0, Convert.ToInt32(MathF.Round(speed / 2)));
        		
        		if(percentage + increment > 100) percentage = 100;
        		else percentage += increment;
        		
        		if(increment > 0) {
        		    Console2.Clear();
        		    Console2.WriteLine(loadingType + " Status: "+ percentage +"%");
        	    }
        		
        		if(rnd.Next(0, 100) < waitingPercentage) System.Threading.Thread.Sleep(rnd.Next(0, speed * 30));
        	}
        	
        	//clear and display that the loading is finished
        	Console2.Clear();
        	Console2.Write(loadingType +" Status: Finished ");
        	Thread.Sleep(220);
        	Console2.WriteLine(loadingName);
        	Thread.Sleep(loadingName.Length * 48);
        	Console2.Clear();
        }
    }
}