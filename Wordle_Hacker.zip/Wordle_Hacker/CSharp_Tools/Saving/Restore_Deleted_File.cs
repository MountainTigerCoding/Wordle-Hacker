﻿using System;
using System.IO;

namespace CSharpTools
{
    public static class RestoreFile
    {         
        public static void Restore(string path) {
        	//check if the file does not exist
        	if(File.Exists(path)) return;
        	
        	Random rnd = new Random();
        	
        	//save and clear the current text to load after completed
        	TextSave textSave = new TextSave();
        	textSave.OverwriteFromSave(Console2.textSave);
        	Console2.Clear();
        	
        	//display the file not being present
        	Console2.Sleep(rnd.Next(400, 700));
        	Console2.WriteLineIncorrect("File at: "+ path +" does not exist", false);
        	Console2.WriteLine(false);
        	Console2.Sleep(600);
        	
        	//restore the file
        	Console2.Write("Restoring file", false);
        	Console2.Sleep(500);
        	for(int i = 0; i < rnd.Next(4, 14); i++) {
        		Console2.Sleep(rnd.Next(100, 500));
        		Console2.Write(".");
        	}
        	Console2.WriteLine(false);
        	Console2.WriteLine(false);
        	
            //write the file
            File.WriteAllText(path, null);
            Console2.WriteLineCorrect("File created at: "+ path, false);
            Console2.WriteLine(false);
            Console2.Sleep(2000);
        	
            //reset the screen to before
            Console2.Clear();
            textSave.PrintText();
        }
    }
}