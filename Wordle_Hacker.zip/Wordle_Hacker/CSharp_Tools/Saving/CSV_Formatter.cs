﻿using System.IO;
using System.Collections.Generic;

namespace CSharpTools.Formatters
{
    public static class CSVFormatter
    {         
        public static void WriteCSV(string path, string[] array) {
        	if(array.Length == 1) return;
        	
        	FileStream stream = File.Open(path, FileMode.Create);
        	StreamWriter writer = new StreamWriter(stream);
        	
        	int i = 0;
        	foreach(string element in array) {
        		if(element != "") {
        			writer.Write("\""+ element +"\"");
        			if(i != array.Length - 1) writer.WriteLine(",");
        		}
        		i++;
        	}
        	
        	writer.Close();
       }
        
        public static string[] ReadAllCSV(string path) {
			FileStream stream = File.Open(path, FileMode.Open);
			StreamReader reader = new StreamReader(stream);
			
			string rawString = "";
			while(!reader.EndOfStream) rawString += reader.ReadLine(); 
			reader.Close();
        	
        	List<string> CSVstring = new List<string>();
        	
        	if(rawString.Length > 0) {
        		SplitCSVString(rawString);
        		
        	    int i = 0;
        	    foreach(string element in rawString.Split(",")) {
        	    	string temp = element;
        	    	temp = temp.Remove(0, 1);
        	    	temp = temp.Remove(temp.Length - 1, 1);
            		CSVstring.Add(temp);
            		i++;
        	    }
        	    
        	}else CSVstring.Add("");
            
		    return CSVstring.ToArray();
        }
        
        private static void SplitCSVString(string csvString) {
        	
        	List<string> items = new List<string>();
        	bool insideString = false;
        	int insideStringStartIdx = 0; 
        	
        	int i = 0;
        	foreach(char letter in csvString +" ") {
        		if(letter == '"' && !insideString) {
        			insideString = true;
        			insideStringStartIdx = i;
        		}
        		
        		i++;
        	}
        }
    }
}