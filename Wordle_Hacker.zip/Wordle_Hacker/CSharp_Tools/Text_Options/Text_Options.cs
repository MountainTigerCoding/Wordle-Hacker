﻿using System;
using System.Threading;

namespace CSharpTools
{
    public class TextOptions
    {
    	public string[] options {get; set;}
    	public string margin {get; set;}
    	
        public TextOptions(string margin = "", params string[] options) {
        	this.margin = margin;
        	this.options = options;
        }
        
        public void Print(bool saveText = true) {
        	int i = 1;
        	
        	//print each element in the array one by one
        	foreach(string element in options) {
        		//print each element in the array with some time animation
        		Console2.WriteAnimateLetters(margin + i +". ", 80, saveText);
        		Console2.Sleep(100);
        		Console2.Write(element, saveText);
        		
        		Console2.WriteLine(saveText);
        		Console2.Sleep(100);
        		
        		i++;
        	}
        }
        
        //askes for a valid input from the user relating to the array
        public (int, string) AskForIndexInput() {
        	TextSave textSave = new TextSave();
        	textSave.OverwriteFromConsoleSave();
        	
        	int parsedResult = 0;
        	bool stopWhile = true;
        	
        	//repeat until the input is valid
        	while(stopWhile) {
        		Console2.Write(margin);
        		string input = Console.ReadLine() ?? "AskForIndexInput.Console.ReadLine.return value = null";
        	    
        	    if(int.TryParse(input, out parsedResult)) {


        	    	if(parsedResult >= 1 && parsedResult <= options.Length) {
        	    		//if input is in range then leave the loop
        	    		stopWhile = false;
        	    		break;
        	    	}else Console2.WriteIncorrect(margin + "Index has to be in range");
        	    	
        	    }else{
        	    	Console2.WriteIncorrect(margin + "Input was not a number");
        	    }
        	    
        	    Console2.Sleep(1000);
        	    Console2.Clear();
        	    textSave.PrintText();
        	}
        	
        	return (parsedResult, options[parsedResult - 1]);
        }
    }
}