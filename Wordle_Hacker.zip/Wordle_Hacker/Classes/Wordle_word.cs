﻿using System;
using CSharpTools;
using System.Collections.Generic;

namespace WordleHacker
{
	public class WordleWord
	{
		public List<WordleLetter> letters = new List<WordleLetter>();
		public string word {get => GetWord();}
		public WordleWord() {}
		
		public void AddLetter(WordleLetter letter)
		{
			if (letters.Count < 5) letters.Add(letter);
			else Console2.WriteLineIncorrect("Cannot add letter to dictionary because it has a length greater than 5.");
		}
		
		private string GetWord()
		{
			string word = "";
			foreach(WordleLetter letter in letters) word += letter.letter;
			return word;
		}
		
		public int Contains(LetterState letterState)
		{
			int numFound = 0;
			foreach(WordleLetter letter in letters)
			{
				if(letter.state == letterState) numFound++;
			}
			return numFound;
		}
		
		public int Contains(WordleLetter wordleLetter)
		{
			int numFound = 0;
			foreach(WordleLetter letter in letters)
			{
				if(letter.letter == wordleLetter.letter && letter.state == wordleLetter.state) numFound++;
			}
			return numFound;
		}
	}

	public struct WordleLetter
	{
		public readonly char letter;
		public readonly LetterState state;

		public WordleLetter(char letter, LetterState state)
		{
			this.letter = letter;
			this.state = state;
		}
	}

	public enum LetterState { CorrectLocation, WrongLocation, DoesNotContain }
}