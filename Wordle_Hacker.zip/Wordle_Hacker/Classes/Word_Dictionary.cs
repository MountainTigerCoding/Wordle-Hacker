﻿using System.IO;
using System.Collections.Generic;

namespace WordleHacker
{
	public class WordDictionary
	{
		public string[] words {get; set;}
		
		public WordDictionary(string path) {
			words = new string[0];
			FindWordsInDictionary(path);
		}
		
		private void FindWordsInDictionary(string path) {
			string[] tempWords = File.ReadAllText(path).Split('\n');
			List<string> foundWords = new List<string>();
			
			foreach(string word in tempWords) {
				string refinedWord = word.Trim(' ');
				if(refinedWord.Length == 5 && refinedWord.Length > 0) foundWords.Add(refinedWord);
			}
			
			words = foundWords.ToArray();
		}
    }
}