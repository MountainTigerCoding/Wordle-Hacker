﻿using System;
using System.IO;
using CSharpTools;
using System.Linq;
using System.Collections.Generic;

namespace WordleHacker
{
	public class WordleDictionary
	{
		public List<string> words = new List<string>();
		public readonly int wordsSearched = 0;

		public WordleDictionary() { }

		public WordleDictionary(bool copyWithoutWait, params WordDictionary[] dictionaries)
		{
			(wordsSearched, words) = FindWords(copyWithoutWait, ref dictionaries);
		}

		public WordleDictionary(string path, bool copyWithoutWait, params WordDictionary[] dictionaries)
		{
			(wordsSearched, words) = FindWords(copyWithoutWait, ref dictionaries);

			FileStream stream = File.Create(path);
			StreamWriter writer = new StreamWriter(stream);
			foreach (string word in words) writer.WriteLine(word);
			writer.Close();
		}
		
		//flter though a dictionary[] and filter non duplicating
		//words into the wordle dictionary
		private (int, List<string>) FindWords(bool copyWithoutWait, ref WordDictionary[] dictionaries)
		{
			List<string> words = new List<string>();
			int numberOfWords = 0;
			foreach (WordDictionary dictionary in dictionaries) numberOfWords += dictionary.words.Length;

			int i = 0;
			Random rnd = new Random();

			foreach (WordDictionary dictionary in dictionaries)
			{
				foreach (string word in dictionary.words)
				{
					if (!copyWithoutWait) {
						if (i % rnd.Next(60, 150) == 0) {
							Console2.Clear();
							Console2.WriteLine(i + " out of " + numberOfWords + " words checked.");
						}
					}

					if (!words.Contains(word)) words.Add(word);
					i++;
				}
			}
			if(!copyWithoutWait) Console2.WriteLineCorrect("Finished!", 1500);
			return (i, words);
		}
		
		//get a wordle dictionary from a text file
		public static WordleDictionary ReadWordleDictionary(string path)
		{
			WordDictionary dictionary = new WordDictionary(path);
			return new WordleDictionary(true, dictionary);
		}
		
		//filter the wordle dictionary using a wordle word
		public void FilterDictionary(WordleWord wordleWord)
		{
			List<string> filteredWords = new List<string>();
			foreach(string word in words)
			{
				bool addWord = true;
				int i = 0;
				foreach(WordleLetter letter in wordleWord.letters)
				{
					if(word.Length == 0) continue;

					switch(letter.state)
					{
						case LetterState.DoesNotContain:
							int greyLetters = wordleWord.Contains(letter);
							int greenLetters = wordleWord.Contains(new WordleLetter(letter.letter, LetterState.CorrectLocation));
							
							if(greyLetters > greenLetters || word == wordleWord.word) {
								if(word.Contains(letter.letter)) addWord = false;
							}
							break;
						
						case LetterState.WrongLocation:
							if(!word.Contains(letter.letter) || word[i] == letter.letter) addWord = false;
							break;
							
						case LetterState.CorrectLocation:
							if(letter.letter != word[i]) addWord = false;
							break;
						
						default:
							break;
					}
					i++;
				}
				if(addWord && word.Length > 0) filteredWords.Add(word);
			}
			words = filteredWords;
		}
		
		public void TotxtFile(string path)
		{
			FileStream stream = File.Open(path, FileMode.Create);
			StreamWriter writer = new StreamWriter(stream);
			
			int i = 0, writeType = 0;
			foreach(string word in words)
			{
				if(word.Length == 5 && i != words.Count - 1) {
					if(writeType == 5) {
						writer.WriteLine(word +", ");
						writeType = 0;
					}else writer.Write(word +", ");
					writeType++;
				}

				i++;
			}
			writer.Close();
		}
		
		public void Sort()
		{
			List<RefinedWord> sortedWords = new List<RefinedWord>();
			sortedWords.Add(new RefinedWord("", -1000));
			WordDictionary frequentEnglish= new WordDictionary(Hacker.commonEnglishPath); 
			WordDictionary wordleWords = new WordDictionary(Hacker.wordleWordsPath);
			
			foreach(string word in words)
			{
				int i = 0;
				float weight = FindWeight(word);
				
				if(Hacker.currentTurn >= 2) if(wordleWords.words.Contains(word)) weight *= 2f;
				
				int value = FindWordValue(ref frequentEnglish, word);
				if(value > 0) weight += value;
				
				weight += FindValueOfInfomation(word);
				if(Hacker.currentTurn <= 2) weight -= (FindDuplicateValue(word) * 30);
				
				while(weight < sortedWords[i].weight) i++;
				sortedWords.Insert(i, new RefinedWord(word, weight));
			}
			
			words.Clear();
			foreach(RefinedWord word in sortedWords) words.Add(word.word);
		}
		
		private float FindWeight(string word)
		{
			float weight = 0;
			List<char> foundLetters = new List<char>();
				
			foreach(char letter in word)
			{
				if(!foundLetters.Contains(letter)) foundLetters.Add(letter);
			}
				
			weight = foundLetters.Count;
			return weight;
		}
		
		private int FindWordValue(ref WordDictionary dictionary, string inputWord)
		{
			int value = 0;
			for(int i = dictionary.words.Length - 1; i > -1; i--)
			{
				string word = dictionary.words[i];
				if(word == inputWord) return value;
				value++;
			}
			return -1;
		}
		
		public static float FindValueOfInfomation(string word)
		{
			float value = 0;
			foreach(char letter in word) {
				if(letter != '�') value += Hacker.letterValues[letter];
			}
			return value;
		}
		
		private int FindDuplicateValue(string word)
		{
			int value = 0;
			int idx = 0, idx2 = 0;;
			foreach(char letter in word)
			{
				idx2 = 0;
				foreach(char letter2 in word)
				{
					if(letter == letter2 && idx != idx2) value++;
					idx2++;
				}
				
				idx++;
			}
			return value;
		}
		
		public TextSave ToTextSave()
		{
			TextSave save = new TextSave();
			int writeType = 0;
			foreach(string word in words)
			{
				
				if(writeType == 4) save.textLines.Add(new TextLineSave(word +", ", TextPrintMode.WriteLine));
				else save.textLines.Add(new TextLineSave(word +", ", TextPrintMode.Write));
				writeType++;
			}
			return save;
		}
	}
}