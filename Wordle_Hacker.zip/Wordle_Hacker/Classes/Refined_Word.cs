﻿namespace WordleHacker
{
    public class RefinedWord 
    {         
        public string word;
        public float weight = 0;
        
        public RefinedWord(string word, float weight) {
        	this.word = word;
        	this.weight = weight;
        }
    }
}